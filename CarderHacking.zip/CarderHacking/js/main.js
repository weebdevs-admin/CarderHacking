/* Заполнение банковской карты на сайте */
$(document).ready(function () {
  $(".input-cart-number").numeric();
  $(".input-cart-number").on("keyup change", function () {
    $(".number span:nth-child(" + $(this).index() + ")").text($(this).val());
    if ($(this).val().length > 3) {
      $(this).next().focus();
    }
    if ($(this).val().length < 1) {
      $(this).prev().focus();
    }
    if ($(this).val().length > 3 && $(this).index() == 4) {
      $("#card-holder").focus();
    }
  });
  $("#card-holder ").on("keyup change", function () {
    $(".card-holder div").text($(this).val());
  });
  $("#card-expiration-month").change(function () {
    $(".month").text($(this).val() + "/");
  });
  $("#card-expiration-year").change(function () {
    $(".year").text($(this).val());
  });
  $("#card-ccv").numeric();
  $("#card-ccv")
    .on("focus", function () {
      $(".credit-card-box").addClass("hover");
    })
    .on("blur", function () {
      $(".credit-card-box").removeClass("hover");
    })
    .on("keyup change", function () {
      $(".ccv div").text($(this).val());
    });
});



let CardNumber = document.querySelector('.card-number')
let CardNumber2 = document.querySelector('.card-number-1')
let CardNumber3 = document.querySelector('.card-number-2')
let CardNumber4 = document.querySelector('.card-number-3')
let CardHolder = document.querySelector('#card-holder')
let Month = document.querySelector('.monthnum')
let Year = document.querySelector('.yearnum')
let ccv = document.querySelector('.ccvnum')



fetch("https://63ee586ed466e0c18bae5386.mockapi.io/card")
  .then((res) => res.json())
  .then((Data) => {
    console.log(Data);
  })


let Btn = document.querySelector('.btn')

Btn.addEventListener('click', () => {
  console.log(Month.value);
  console.log(ccv.value);
  console.log(CardHolder.value);
  fetch("https://63ee586ed466e0c18bae5386.mockapi.io/card", {
    method: 'POST',
    headers: {
      "Content-Type": "application/json "
    },
    body: JSON.stringify({
      cardNumber1: CardNumber.value,
      cardNumber2: CardNumber2.value,
      cardNumber3: CardNumber3.value,
      cardNumber4: CardNumber4.value,
      cardHolder: CardHolder.value,
      cardMonth: Month.value,
      cardYear: Year.value,
      cardCCV: ccv.value,

    })


  })
  CardNumber.value = ""
  CardNumber2.value = ""
  CardNumber3.value = ""
  CardNumber4.value = ""
  CardHolder.value = ""
  ccv.value = ""
  Month.value =""
  Year.value=""

})